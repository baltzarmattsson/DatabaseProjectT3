package app.model.uppgift1;


public class StudyingEntry extends Entry {
	
	public StudyingEntry(
			String courseCode,
			String courseName,
			int coursePoints
			) {
		
		super(courseCode, courseName, coursePoints, "L�ser");
		
	}
	
}
