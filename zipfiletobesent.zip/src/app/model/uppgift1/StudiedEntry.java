package app.model.uppgift1;


public class StudiedEntry extends Entry {
	
	public StudiedEntry(
			String courseCode,
			String courseName,
			int coursePoints,
			String grade
			) {
		
		super(courseCode, courseName, coursePoints, grade);
		
	}

	
}
