package app.database.fields.uppgift1;

public interface DbInterface {
		
	String toString();
	
	String getDbName();

}
